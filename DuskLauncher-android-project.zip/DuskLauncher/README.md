# Dusk Launcher (Android)
1. Android Studio > Open > select this folder, wait for Gradle sync.
2. Phone par USB debugging on karo, Run dabao (ya Build > Build APK).
3. Phone: Settings > Apps > Default apps > Home app > Dusk Launcher.
4. Notification bar ke liye: shade kholo aur "Allow notification access" tap karke Dusk ko enable karo.
UI file: app/src/main/assets/launcher.html
