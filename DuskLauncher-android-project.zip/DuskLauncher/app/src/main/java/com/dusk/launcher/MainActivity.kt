package com.dusk.launcher

import android.app.Activity
import android.content.*
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val icons = HashMap<String, String>()

    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.navigationBarColor = 0xFF05080D.toInt()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        web = WebView(this)
        web.setBackgroundColor(0xFF0A1620.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/launcher.html")
        setContentView(web)
        NotifService.onChange = { runOnUiThread { js("window.onNotifs&&onNotifs()") } }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package")
        }
        registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { js("window.onApps&&onApps()") }
        }, f)
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); js("window.onHome&&onHome()") }
    @Suppress("DEPRECATION")
    override fun onBackPressed() { js("window.onHome&&onHome()") }
    private fun js(s: String) = web.evaluateJavascript(s, null)

    private fun enc(d: Drawable): String {
        val bm = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 96, 96); d.draw(Canvas(bm))
        val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.PNG, 90, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    inner class Bridge {
        @JavascriptInterface fun getApps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach { r ->
                    val p = r.activityInfo.packageName
                    arr.put(JSONObject().put("n", r.loadLabel(pm).toString()).put("p", p)
                        .put("i", icons.getOrPut(p) { enc(r.loadIcon(pm)) }))
                }
            return arr.toString()
        }
        @JavascriptInterface fun launch(p: String) {
            packageManager.getLaunchIntentForPackage(p)?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it) }
        }
        @JavascriptInterface fun getNotifs() = NotifService.dump()
        @JavascriptInterface fun openNotif(k: String) = NotifService.open(k)
        @JavascriptInterface fun dismiss(k: String) = NotifService.dismiss(k)
        @JavascriptInterface fun clearAll() = NotifService.clearAll()
        @JavascriptInterface fun hasAccess() =
            Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        @JavascriptInterface fun grantAccess() {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun settings(w: String) {
            val a = when (w) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bt" -> Settings.ACTION_BLUETOOTH_SETTINGS
                else -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            }
            startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun torch(on: Boolean) {
            try { val m = getSystemService(CAMERA_SERVICE) as CameraManager; m.setTorchMode(m.cameraIdList[0], on) } catch (e: Exception) {}
        }
        @JavascriptInterface fun battery() =
            (getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }
}
