package com.dusk.launcher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class NotifService : NotificationListenerService() {
    companion object {
        var inst: NotifService? = null
        var onChange: (() -> Unit)? = null

        fun dump(): String {
            val out = JSONArray()
            val s = inst ?: return "[]"
            try {
                s.activeNotifications.sortedByDescending { it.postTime }.forEach { n ->
                    val e = n.notification.extras
                    val t = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                    val x = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
                    if ((t.isEmpty() && x.isEmpty()) || (n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return@forEach
                    val pm = s.packageManager
                    val app = try { pm.getApplicationLabel(pm.getApplicationInfo(n.packageName, 0)).toString() } catch (ex: Exception) { n.packageName }
                    out.put(JSONObject().put("k", n.key).put("p", n.packageName).put("a", app).put("t", t).put("x", x).put("w", n.postTime))
                }
            } catch (ex: Exception) {}
            return out.toString()
        }
        fun open(k: String) {
            val n = inst?.activeNotifications?.find { it.key == k } ?: return
            try { n.notification.contentIntent?.send() } catch (e: Exception) {}
            if ((n.notification.flags and Notification.FLAG_AUTO_CANCEL) != 0) inst?.cancelNotification(k)
        }
        fun dismiss(k: String) { try { inst?.cancelNotification(k) } catch (e: Exception) {} }
        fun clearAll() { try { inst?.cancelAllNotifications() } catch (e: Exception) {} }
    }
    override fun onListenerConnected() { inst = this; onChange?.invoke() }
    override fun onListenerDisconnected() { inst = null }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { onChange?.invoke() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { onChange?.invoke() }
}
